Ext.define('MyDesktop.WallpaperModel', {
    extend: 'Ext.data.TreeModel',
    fields: [
        { name: 'text' },
        { name: 'img' }
    ]
});
